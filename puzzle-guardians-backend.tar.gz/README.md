# Puzzle & Guardians Backend API

Vercel Serverless Function으로 구동되는 백엔드 API

## 🚀 배포 방법

### 1. GitHub 저장소 생성
1. GitHub에서 새 저장소 생성 (예: `puzzle-guardians-backend`)
2. 이 폴더의 모든 파일 업로드

### 2. Vercel 배포
1. https://vercel.com 접속
2. "Import Project" 클릭
3. GitHub 저장소 선택
4. "Deploy" 클릭
5. 완료! 🎉

### 3. API 엔드포인트
배포 후 다음 URL로 접근 가능:
```
https://your-project-name.vercel.app/api/transactions
```

## 📦 API 응답 형식

```json
{
  "success": true,
  "cached": false,
  "count": 234,
  "transactions": [
    {
      "timestamp": 1698765432000,
      "to": "0x...",
      "amount": 20,
      "token": "BORA",
      "txHash": "0x...",
      "blockNumber": 12345678
    }
  ]
}
```

## ⚡ 기능
- ✅ 자동 캐싱 (5분)
- ✅ CORS 지원
- ✅ 5000 블록씩 분할 조회
- ✅ Rate limit 방지
- ✅ 에러 처리

## 🔧 환경 변수 (선택사항)
Vercel 대시보드에서 추가 가능:
- `KAIA_RPC_URL`: RPC 엔드포인트 (기본값: BlockPI)
- `WALLET_ADDRESS`: 지갑 주소
- `BORA_TOKEN_ADDRESS`: BORA 토큰 주소

## 📝 로그 확인
Vercel 대시보드 > Functions > Logs에서 확인 가능
